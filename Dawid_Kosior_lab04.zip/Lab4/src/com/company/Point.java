package com.company;

public class Point {
    int x, y;
    Point(){

    }
    public Point(int x, int y){
        this.x = x;
        this.y = y;
    }
}
